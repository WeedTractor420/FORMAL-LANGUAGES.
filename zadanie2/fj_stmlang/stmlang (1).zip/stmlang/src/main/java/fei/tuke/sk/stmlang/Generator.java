package fei.tuke.sk.stmlang;

import java.io.IOException;
import java.io.Writer;

public class Generator {
    private final StateMachineDefinition stateMachine;
    private final Writer writer;

    public Generator(StateMachineDefinition stateMachine, Writer writer) {
        this.stateMachine = stateMachine;
        this.writer = writer;
    }

    public void generate() throws IOException {

    }

    private void writeState(String name, StateDefinition state) throws IOException {

    }
}