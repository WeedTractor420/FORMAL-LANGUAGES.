package fei.tuke.sk.stmlang;

public class Main {
    public static void main(String[] args) {
        //TODO your code goes here
    }
}