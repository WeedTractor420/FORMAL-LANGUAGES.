package fei.tuke.sk.stmlang;

public record TransitionDefinition(String commandName, String targetName) {

}