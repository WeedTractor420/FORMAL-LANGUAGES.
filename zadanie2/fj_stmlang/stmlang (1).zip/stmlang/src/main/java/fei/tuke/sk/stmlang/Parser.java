package fei.tuke.sk.stmlang;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
Grammar:
        * StateMachine  -> { Statement }
        * Statement     -> Commands | ResetCommands | Events | State
        * Commands      -> "commands" "{" { NAME CHAR } "}"
        * Events        -> "events" "{" { NAME CHAR } "}"
        * ResetCommands -> "resetCommands" "{" { NAME } "}"
        * State         -> "state" "{" [Actions] { Transition } "}"
        * Actions       -> "actions" "{" { NAME } "}"
        * Transition    -> NAME "->" NAME
 */

public class Parser {
    private final Lexer lexer;
    private Token symbol;
    private StateMachineDefinition definition;

    public Parser(Lexer lexer) {
        this.lexer = lexer;
    }

    public StateMachineDefinition stateMachine() {
        definition = new StateMachineDefinition();
        var first = Set.of(
                TokenType.COMMANDS,
                TokenType.EVENTS,
                TokenType.RESET_COMMANDS,
                TokenType.STATE);
        consume();
        while (first.contains(symbol.tokenType())) {
            switch (symbol.tokenType()) {
                case COMMANDS -> commands();
                case EVENTS -> events();
                case RESET_COMMANDS -> resetCommands();
                case STATE -> state();
            }
        }
        match(TokenType.EOF);
        return definition;
    }

    private void commands() {
        //TODO your code goes here
        definition.addCommand(null, ' ');
    }

    private void events() {
        //TODO your code goes here
        definition.addEvent(null, ' ');
    }

    private void resetCommands() {
        //TODO your code goes here
        definition.addResetCommands(null);
    }

    private void state() {
        //TODO your code goes here (actions + transitions)
    }

    private List<String> actions(){
        //TODO your code goes here
        return new ArrayList<>();
    }

    private TransitionDefinition transition() {
        //TODO your code goes here
        return new TransitionDefinition(null, null);
    }

    private void match(TokenType expectedSymbol) {
        //TODO your code goes here
    }

    private void consume() {
        //TODO your code goes here
    }
}
