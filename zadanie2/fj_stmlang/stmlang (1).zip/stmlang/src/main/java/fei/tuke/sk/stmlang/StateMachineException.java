package fei.tuke.sk.stmlang;

public class StateMachineException extends RuntimeException {
    //TODO your code goes here
}