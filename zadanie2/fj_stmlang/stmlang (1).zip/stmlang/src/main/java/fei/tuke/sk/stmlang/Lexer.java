package fei.tuke.sk.stmlang;

import java.io.Reader;
import java.util.Map;

/**
 * Lexical analyzer of the state machine language.
 */
public class Lexer {
    private static final Map<String, TokenType> keywords = Map.of(
            "commands", TokenType.COMMANDS,
            "resetCommands", TokenType.RESET_COMMANDS,
            "events", TokenType.EVENTS,
            "state", TokenType.STATE,
            "actions", TokenType.ACTIONS
    );

    private final Reader input;
    private int current;

    public Lexer(Reader input) {
        this.input = input;
    }

    public Token nextToken() {
        //TODO  your code goes here
        return new Token(null);
    }

    private Token readNameOrKeyword() {
        //TODO your code goes here
        return new Token(null);
    }

    private void consume() {
        //TODO your code goes here
    }
}